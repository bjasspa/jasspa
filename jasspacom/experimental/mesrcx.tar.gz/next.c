/* -*- c -*-
 *
 * JASSPA MicroEmacs - www.jasspa.com
 * next.c - Next file/line goto routines.
 *
 * Copyright (C) 1994-2001 Steven Phillips
 * Copyright (C) 2002 JASSPA (www.jasspa.com)
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge, MA 02139, USA.
 */
/*
 * Created:     01/06/1994
 * Synopsis:    Next file/line goto routines.
 * Authors:     Steven Phillips
 */

/*---	Include defintions */

#define	__NEXTC	1			/* Define the filename */

/*---	Include files */

#include "emain.h"
#include "esearch.h"

#if MEOPT_FILENEXT

static int
flNextFind(meUByte *str, meUByte **curFilePtr, meInt *curLine)
{
    meUByte   pat[MAXBUF], *ss, cc ;
    meUByte  *n=NULL ;
    int     buffRpt=-1, fileRpt=-1, lineRpt=-1, onRpt=0 ;
    int     soff, len ;
    
    ss = str+1 ;
    soff = 0 ;
    while((soff < NPAT) && ((cc=*ss++) != '\0'))
    {
        if(cc == '%')
        {
            switch((cc=*ss++))
            {
            case 'b':
                buffRpt = onRpt++ ;
                n = (meUByte *) ".*" ;
                break ;
            case 'f':
                fileRpt = onRpt++ ;
                n = flNextFileTemp ;
                break ;
            case 'l':
                lineRpt = onRpt++ ;
                n = flNextLineTemp ;
                break ;
            }
        }
        if(n != NULL)
        {
            pat[soff++] = '\\' ;
            pat[soff++] = '(' ;
            meStrcpy(pat+soff,n) ;
            soff += meStrlen(n) ;
            pat[soff++] = '\\' ;
            pat[soff++] = ')' ;
            n = NULL ;
        }
        else
            pat[soff++] = cc ;
    }
    if(soff >= NPAT)
        return mlwrite(MWABORT,(meUByte *)"[Search string to long]") ;
    pat[soff] = '\0' ;

    if(iscanner(pat,1,ISCANNER_PTBEG|ISCANNER_MAGIC|ISCANNER_EXACT,NULL) != TRUE)
        return 0 ;

    /* Found it, is it an ignore line? if so return -1 else fill in the slots and return 1. */
    if(*str == '0')
        return -1 ;
    
    soff = curwp->w_doto ;
    if(fileRpt >= 0)
    {
        len = mereRegexGroupEnd(fileRpt+1) - mereRegexGroupStart(fileRpt+1) ;
        meNullFree(*curFilePtr) ;
        if((*curFilePtr = meMalloc(len+1)) == NULL)
            return FALSE ;
        meStrncpy(*curFilePtr,curwp->w_dotp->l_text+soff+mereRegexGroupStart(fileRpt+1),len) ;
        (*curFilePtr)[len] = '\0' ;
    }
    else if(buffRpt >= 0)
    {
        len = mereRegexGroupEnd(buffRpt+1) - mereRegexGroupStart(buffRpt+1) ;
        meNullFree(*curFilePtr) ;
        if((*curFilePtr = meMalloc(len+3)) == NULL)
            return FALSE ;
        (*curFilePtr)[0] = '*' ;
        meStrncpy((*curFilePtr)+1,curwp->w_dotp->l_text+soff+mereRegexGroupStart(fileRpt+1),len) ;
        (*curFilePtr)[len+1] = '*' ;
        (*curFilePtr)[len+2] = '\0' ;
    }
    if(lineRpt >= 0)
        *curLine = meAtoi(curwp->w_dotp->l_text+soff+mereRegexGroupStart(lineRpt+1)) ;

    return 1 ;
}

int
getNextLine(int f,int n)
{
    int     noNextLines, ii, no, rr ;
    meUByte **nextLines ;
    meUByte  *nextFile=NULL ;
    meInt   curLine=-1 ;
    BUFFER *bp=NULL, *tbp ;
    
    for(ii=0 ; ii<noNextLine ; ii++)
    {
        if((tbp = bfind(nextName[ii],0)) != NULL)
        {
            if(tbp == curbp)
            {
                bp = tbp ;
                no = ii ;
                break ;
            }
            if((bp == NULL) || (bp->b_nwnd < tbp->b_nwnd))
            {
                bp = tbp ;
                no = ii ;
            }
        }
    }
    if(bp == NULL)
        return mlwrite(MWABORT,(meUByte *)"[No next buffer found]") ;
    if((noNextLines = nextLineCnt[no]) == 0)
        return mlwrite(MWABORT,(meUByte *)"[No lines for next buffer %s]",bp->b_bname) ;
    nextLines = nextLineStr[no] ;
    
    wpopup(bp->b_bname,WPOP_MKCURR) ;

    if((curwp->w_dotp == bp->b_linep) ||
       ((curwp->w_dotp == lback(bp->b_linep)) &&
        (curwp->w_doto == llength(curwp->w_dotp))))
    {
        curwp->w_dotp = lforw(bp->b_linep) ;
        curwp->w_doto = 0 ;
        curwp->line_no = 0 ;
    }
    while((curwp->line_no)++,
          (curwp->w_dotp = lforw(curwp->w_dotp)) != bp->b_linep)
    {
        ii = noNextLines ;
        while(--ii >= 0)
        {
            curwp->w_doto = 0 ;
            if((rr=flNextFind(nextLines[ii],&nextFile,&curLine)) == ABORT)
            {
                curwp->w_doto = 0 ;
                curwp->w_flag |= WFMOVEL ;
                return ABORT ;
            }
            if(rr == -1)
                /* ignore the line */
                ii = 0 ;
            else if(rr == 1)
            {
                /* matched a line */
                curwp->w_doto = 0 ;
                curwp->w_flag |= WFMOVEL ;
                if(nextFile != NULL)
                {
                    meUByte fname[FILEBUF], *value ;
                    meVARIABLE *var ;
                    
                    ii = meStrlen(nextFile) ;
                    if((nextFile[0] != '*') || (nextFile[ii-1] != '*'))
                    {
                        if(bp->b_fname != NULL)
                        {
                            meUByte tmp[FILEBUF] ;
                            getFilePath(bp->b_fname,tmp) ;
                            meStrcat(tmp,nextFile) ;
                            fileNameCorrect(tmp,fname,NULL) ;
                        }
                        else
                            fileNameCorrect(nextFile,fname,NULL) ;
                        value = fname ;
                    }
                    else
                        value = nextFile ;
                    
                    var = SetUsrLclCmdVar((meUByte *)"next-file",value,&(bp->varList)) ;
                    meFree(nextFile) ;
                    if(var == NULL)
                        return FALSE ;
                    nextFile = var->value ;
                }
                else if((nextFile = getUsrLclCmdVar((meUByte *)"next-file",&(bp->varList))) == errorm)
                    return mlwrite(MWABORT,(meUByte *)"[No File name]") ;
                else
                    ii = meStrlen(nextFile) ;
                if(wpopup(NULL,WPOP_MKCURR) == NULL)
                    return FALSE ;
                if((nextFile[0] == '*') && (nextFile[ii-1] == '*'))
                {
                    BUFFER *bp ;
                    nextFile[ii-1] = '\0' ;
                    if((bp = bfind(nextFile+1,0)) == NULL)
                    {
                        mlwrite(MWABORT,(meUByte *)"[Buffer \"%s\" no longer exists]",nextFile+1) ;
                        nextFile[ii-1] = '*' ;
                        return FALSE ;
                    }
                    nextFile[ii-1] = '*' ;
                    if(swbuffer(curwp,bp) != TRUE)
                        return FALSE ;
                }
                else if(findSwapFileList(nextFile,(BFND_CREAT|BFND_MKNAM),0) != TRUE)
                    return FALSE ;
                if(curLine < 0)
                    return mlwrite(MWABORT,(meUByte *)"[No Line number]") ;
                /* if for some strange reason the file wasn't found, but the directory
                 * was and its read only, the findSwapFileList will succeed (new buffer)
                 * BUT the file name will be null! catch this and just use the buffer name */ 
                mlwrite(0,(meUByte *)"File %s, line %d",
                        (curbp->b_fname == NULL) ? curbp->b_bname:curbp->b_fname,curLine) ;
#if MEOPT_NARROW
                return gotoAbsLine(curLine) ;
#else
                return gotoLine(1,curLine) ;
#endif
            }
        }
    }
    curwp->w_doto = 0 ;
    curwp->w_flag |= WFMOVEL ;
    return mlwrite(MWABORT|MWCLEXEC,(meUByte *)"[No more lines found]") ;
}

int
addNextLine(int f, int n)
{
    meUByte name[MAXBUF], line[MAXBUF] ;
    int no, cnt ;
    
    if(meGetString((meUByte *)"next name",0,0,name,MAXBUF) != TRUE)
        return FALSE ;
    for(no=0 ; no<noNextLine ; no++)
        if(!meStrcmp(nextName[no],name))
            break ;
    if(n == 0)
    {
        if(no != noNextLine)
        {
            cnt = nextLineCnt[no] ;
            while(cnt--)
                meFree(nextLineStr[no][cnt]) ;
            nextLineCnt[no] = 0 ;
        }
        return TRUE ;
    }
    line[0] = (n < 0) ? '0':'1' ;
    if(meGetString((meUByte *)"next line",0,0,line+1,MAXBUF) != TRUE)
        return FALSE ;
    if(no == noNextLine)
    {
        noNextLine++ ;
        if(((nextName=meRealloc(nextName,noNextLine*sizeof(meUByte *))) == NULL) ||
           ((nextName[no]=meStrdup(name)) == NULL) ||
           ((nextLineCnt=meRealloc(nextLineCnt,noNextLine*sizeof(meUByte))) == NULL) ||
           ((nextLineStr=meRealloc(nextLineStr,noNextLine*sizeof(meUByte **))) == NULL))
        {
            noNextLine = 0 ;
            return FALSE ;
        }
        nextLineCnt[no] = 0 ;
        nextLineStr[no] = NULL ;
    }
    cnt = nextLineCnt[no] ;

    if(((nextLineStr[no]=meRealloc(nextLineStr[no],(cnt+1)*sizeof(char *))) == NULL) ||
       ((nextLineStr[no][cnt]=meStrdup(line)) == NULL))
    {
        nextLineCnt[no] = 0 ;
        return FALSE ;
    }
    nextLineCnt[no]++ ;
    return TRUE ;
}

#endif

#if MEOPT_RCS

int
rcsFilePresent(meUByte *fname)
{
    meUByte tname[MAXBUF] ;
    register meUByte *fn, *ld, *tn=tname ;

    if(rcsFile == NULL)
        return FALSE ;

    fn = fname ;
    if((ld = meStrrchr(fname,DIR_CHAR)) != NULL)
    {
        do
            *tn++ = *fn ;
        while(fn++ != ld) ;
    }
    ld = rcsFile ;
    while(*ld != '\0')
    {
        if((*ld == '%') &&
           (*++ld == 'f'))
        {
            meStrcpy(tn,fn) ;
            tn += meStrlen(fn) ;
        }
        else
            *tn++ = *ld ;
        ld++ ;
    }
    *tn = '\0' ;
    return !meTestExist(tname) ;
}

int
doRcsCommand(meUByte *fname, register meUByte *comStr)
{
    meUByte  pat[MAXBUF+1], cc ;
    meUByte  path[FILEBUF] ;
    meUByte *bname ;
    register int ii, len ;
    
    fileNameCorrect(fname,path,&bname) ;
    ii = 0 ;
    while((cc=*comStr++) != '\0')
    {
        if((cc == '%') &&
           (((cc=*comStr++) == '\0') || (cc == 'f') || (cc == 'm')))
        {
			if(cc == '\0')
				break ;
            if(cc == 'f')
            {
                len = meStrlen(bname) ;
                if((ii + len) > MAXBUF)
                    break ;
                meStrcpy(pat+ii,bname) ;
                ii += len ;
            }
            else
            {
                if(meGetString((meUByte *)"Enter message",0,0,pat+ii,MAXBUF-ii) != TRUE)
                    return FALSE ;
                ii = meStrlen(pat) ;
            }
        }
        else
        {
            if(ii >= MAXBUF)
                break ;
            pat[ii++] = cc ;
        }
    }
    if(cc != '\0')
        return mlwrite(MWABORT,(meUByte *)"[command to long]") ;
    pat[ii] = '\0' ;
    *bname = '\0' ;
    /* must do a pipe not an ipipe as its sequential */
    ii = doPipeCommand(pat,path,(meUByte *)"*rcs*",LAUNCH_SILENT) ;

    return ii ;
}

int
rcsCiCoFile(int f, int n)
{
    register meUByte *str ;
    register int lineno, curcol, ss ;

    if(curbp->b_fname == NULL)
        return mlwrite(MWABORT,(meUByte *)"No file name!") ;
    ss = rcsFilePresent(curbp->b_fname) ;
    if(meModeTest(curbp->b_mode,MDVIEW))	/* if read-only then unlock */
    {
        if(n < 0)
            /* already read-only, no changes to undo, return */
            return TRUE ;
            
        if(ss != TRUE)
        {
#ifdef _DOS
            curbp->stats.stmode &= ~0x01 ;
#endif
#ifdef _WIN32
            curbp->stats.stmode &= ~FILE_ATTRIBUTE_READONLY;/* Write permission for owner */
#endif
#ifdef _UNIX
            curbp->stats.stmode |= 00200 ;
#endif
            meModeClear(curbp->b_mode,MDVIEW) ;
            curwp->w_flag |= WFMODE ;
            return TRUE ;
        }
        if((str = rcsCoUStr) == NULL)
            return mlwrite(MWABORT,(meUByte *)"[rcs cou command not set]") ;
    }
    else
    {
        if(n < 0)
        {
            /* unedit changes */
            if(ss != TRUE)
                return mlwrite(MWABORT,(meUByte *)"[rcs file not found - cannot unedit]") ;
            str = rcsUeStr ;
        }
        else
        {
            if(ss == TRUE)
                str = rcsCiStr ;
            else
                str = rcsCiFStr ;
        }
        if(str == NULL)
            return mlwrite(MWABORT,(meUByte *)"[rcs ci or cif command not set]") ;
        if((n >= 0) && meModeTest(curbp->b_mode,MDEDIT) &&
           ((ss=saveBuffer(TRUE,TRUE)) != TRUE))
            return ss ;
    }
    lineno = curwp->line_no ;
    curcol = curwp->w_doto ;
    /* must execute the command and then reload, reload taken from swbuffer */
    if((doRcsCommand(curbp->b_fname,str) != TRUE) ||
       (bclear(curbp) != TRUE) ||
       ((curbp->intFlag |= BIFFILE),(curbp->line_no = lineno+1),
        (swbuffer(curwp,curbp) != TRUE)))
        return FALSE ;
    if(curcol > llength(curwp->w_dotp))
        curwp->w_doto = llength(curwp->w_dotp) ;
    else
        curwp->w_doto = curcol ;

    return TRUE ;
}

#endif
