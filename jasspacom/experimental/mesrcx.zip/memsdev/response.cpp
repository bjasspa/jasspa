// Response.cpp: implementation of the Response class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "meMsdev.h"
#include "Response.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Response::Response()
{

}

Response::~Response()
{

}
