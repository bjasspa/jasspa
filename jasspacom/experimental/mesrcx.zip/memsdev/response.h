// Response.h: interface for the Response class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RESPONSE_H__04708AC1_A0A8_11D2_950C_444553540000__INCLUDED_)
#define AFX_RESPONSE_H__04708AC1_A0A8_11D2_950C_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class Response  
{
public:
	Response();
	virtual ~Response();

};

#endif // !defined(AFX_RESPONSE_H__04708AC1_A0A8_11D2_950C_444553540000__INCLUDED_)
