/* -*- c -*-
 *
 * JASSPA MicroEmacs - www.jasspa.com
 * emode.h - Define interface to the modes.
 *
 * Copyright (C) 1998-2002 JASSPA (www.jasspa.com)
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge, MA 02139, USA.
 */
/*
 * Created:     Thu Jan 15 1998
 * Synopsis:    Define interface to the modes.
 * Authors:     Steven Phillips
 * Description:
 *      Includes emode.def to create an ordered list of global/buffer modes.
 *
 * Notes:
 *      The modes were originally defined in edef.h.
 *      The list MUST be ordered for the message-line auto-complete to work.
 */

#ifndef __EMODE_H
#define __EMODE_H

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

/* Expand the mode definitions from the .def file */
#define DEFMODE(varnam,strnam,chrnam,masklbl,maskval) varnam,
enum
{
#include "emode.def"
    MDNUMMODES
};
#undef DEFMODE

#define MDNUMBYTES (MDNUMMODES+7)/8

#define meModeCopy(md,ms)     (memcpy((md),(ms),sizeof(meMODE)))
#define meModeTest(mb,flag)   ((mb)[(flag) >> 3] &   (1 << ((flag) & 0x07)))
#define meModeSet(mb,flag)    ((mb)[(flag) >> 3] |=  (1 << ((flag) & 0x07)))
#define meModeClear(mb,flag)  ((mb)[(flag) >> 3] &= ~(1 << ((flag) & 0x07)))
#define meModeToggle(mb,flag) ((mb)[(flag) >> 3] ^=  (1 << ((flag) & 0x07)))

typedef meUByte meMODE[MDNUMBYTES] ;


extern meMODE globMode ;                /* global editor mode		*/
extern meMODE modeLineDraw ;
extern meUByte *modeName[] ;		/* name of modes		*/
extern meUByte  modeCode[] ;		/* letters to represent modes	*/


#ifdef	INC_MODE_DEF

#define DEFMODE(varnam,strnam,chrnam,masklbl,maskval) (meUByte *)strnam,
meUByte *modeName[] = {                  /* name of modes                */
#include "emode.def"
    NULL
};
#undef DEFMODE

#define DEFMODE(varnam,strnam,chrnam,masklbl,maskval) chrnam,
meUByte modeCode[] =
{
#include "emode.def"
};
#undef DEFMODE

#define DEFMODE(varnam,strnam,chrnam,masklbl,maskval) masklbl=maskval,
enum
{
#include "emode.def"
} ;
#undef DEFMODE

meMODE globMode =
#ifdef _WIN32
{ MDAUTO_MASK|MDATSV_MASK|MDBACK_MASK|MDCRLF_MASK, MDEXACT_MASK|MDFENCE_MASK, MDMAGIC_MASK, MDQUIET_MASK|MDTAB_MASK|MDUNDO_MASK, 0 } ;
#else
#ifdef _DOS
{ MDAUTO_MASK|MDATSV_MASK|MDBACK_MASK|MDCRLF_MASK|MDCTRLZ_MASK, MDEXACT_MASK|MDFENCE_MASK, MDMAGIC_MASK, MDQUIET_MASK|MDTAB_MASK|MDUNDO_MASK, 0 } ;
#else
{ MDAUTO_MASK|MDATSV_MASK|MDBACK_MASK, MDEXACT_MASK|MDFENCE_MASK, MDMAGIC_MASK, MDQUIET_MASK|MDTAB_MASK|MDUNDO_MASK, 0 } ;
#endif /* _DOS */
#endif /* _WIN32 */

meMODE modeLineDraw = { 
    MDAUTO_MASK|MDATSV_MASK|MDBACK_MASK|MDBINRY_MASK|MDCMOD_MASK|MDCRYPT_MASK,
    MDDIR_MASK|MDEXACT_MASK|MDINDEN_MASK|MDJUST_MASK,
    MDMAGIC_MASK|MDNRRW_MASK|MDOVER_MASK,
    MDRBIN_MASK|MDTAB_MASK|MDTIME_MASK|MDUNDO_MASK|MDUSR1_MASK|MDUSR2_MASK,
    MDUSR3_MASK|MDUSR4_MASK|MDUSR5_MASK|MDUSR6_MASK|MDUSR7_MASK|MDUSR8_MASK|MDVIEW_MASK|MDWRAP_MASK
} ;

#endif /* INC_MODE_DEF */

#if defined(__cplusplus) || defined(c_plusplus)
}
#endif
#endif /* __EMODE_H */
