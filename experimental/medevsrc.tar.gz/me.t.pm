/* XPM */
static char * me_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 5 1 0 0",
/* colors */
" 	c #00000000FFFF",
".	s iconColor1	m black	c black",
"X	s none	m none	c none",
"o	s iconColor6	m white	c yellow",
"O	c #FFFF00000000",
/* pixels */
"                ",
".              .",
"................",
"X.....oooo.....X",
"XX...oooooo....X",
"XX..ooo..ooo..XX",
"XXX.oo....oo..XX",
"XXX.oooooooo.XXX",
"XXX.oo.......XXX",
"XXX.oo......XXXX",
"XXXX.oooooooXXXX",
"XXXXX.oooo..XXXX",
"XXXXXX.OOO.XXXXX",
"XXXXXX.OOO.XXXXX",
"XXXXXXX.O.XXXXXX",
"XXXXXXXX.XXXXXXX"};
